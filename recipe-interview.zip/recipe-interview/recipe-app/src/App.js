import React, {useState} from 'react';
import './App.css';

// App constants and wordings
import {TITLES} from './constants';

// App components
import Form       from './components/Form';
import ResultsList from './components/ResultsList';

function App() {
  const [resultsList, setResultsList] = useState(null);

  return (
    <div className='main'>
      <h1>{TITLES.main}</h1>
      <Form setResultsList={setResultsList} />
      <ResultsList results={resultsList} />
    </div>
  );
}

export default App;
