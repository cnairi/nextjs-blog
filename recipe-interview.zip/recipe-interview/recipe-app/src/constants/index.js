export const TITLES = {
	main: 'RECIPES'
};

export const FORM = {
	label_check: 'Your ingredients',
	label_text: 'You want a ',
	placeholder_text: 'Enter your recipe',
	cta: 'search'
};

export const INGREDIENTS = [
	{name: 'tomatoes'},
	{name: 'onions'},
	{name: 'garlic'}
];

export const BASE_URL = 'http://localhost:8888'
