import React, {useState} from 'react';

import {FORM, INGREDIENTS, BASE_URL} from '../constants';

const Form = ({setResultsList}) => {
	const [selectedIngredients, setSelectedIngredients] = useState([]),
		  [recipeName, setRecipeName] = useState('');

	const handleCheckboxChange = (e) => {
		e.persist()
		if (!selectedIngredients.includes(e.target.value)) {
			setSelectedIngredients(selectedIngredients => [...selectedIngredients, e.target.value]);
		} else {
			setSelectedIngredients(selectedIngredients.filter(selectedIngredient => selectedIngredient !== e.target.value));
		}
	};

	const handleTextChange = (e) => {
		setRecipeName(e.target.value);
	};

	const handleSubmit = (e) => {
		e.preventDefault();
		fetch(`${BASE_URL}/api?i=${selectedIngredients.join()}&q=${recipeName}&p=1`)
      		.then(response => response.json())
      		.then(data =>setResultsList(data.results));
	};

	return (
		<form onSubmit={handleSubmit}>
		{FORM.label_check}
		{INGREDIENTS.map((ingredient, index) => 
			<label key={index}>
			{ingredient.name}
			<input
			  name='ingredient'
			  type='checkbox'
			  value={ingredient.name}
			  checked={selectedIngredients.length > 0 ? selectedIngredients.includes(ingredient.name) : false}
			  onChange={handleCheckboxChange} />
		  </label>
		)}

		<label>
		{FORM.label_text}
          <input
            name='numberOfGuests'
            type='text'
			value={recipeName}
			placeholder={FORM.placeholder_text}
            onChange={handleTextChange} />
        </label>

		<input type="submit" value={FORM.cta} />
      </form>
	);
};

export default Form;