import React, {useState, useEffect} from 'react';

const ResultsList = ({results}) => {
	const [topIngredients, setTopIngredients] = useState([]);

	const renderItem = (item, index) => {
		return (
			<div className='list-item' key={index}>
				<p>{item.title}</p>
				<img src={item.thumbnail}/>
				<p>{item.ingredients}</p>
			</div>
		);
	};

	const renderTopIngredients = () => {
		let newArray = [];
		results.forEach(result => {
			let splitIngredients = result.ingredients.split(',');
			newArray = newArray.concat(splitIngredients);
		}
		);
		newArray = newArray.filter((item, index) => newArray.indexOf(item.trim()) === index);
		let ingredientArray = [];
		newArray.map((ingredient, index) => {
			ingredientArray.push({ name: ingredient, count: 0});
			results.forEach(result => {
				if (result.ingredients.includes(ingredient)) {
					ingredientArray[index].count = ingredientArray[index].count + 1;
				}
			}
			);
		})
		ingredientArray.sort(compareIngredients);
		setTopIngredients(ingredientArray);
	}

	useEffect(()=> {
		if (results) {
			renderTopIngredients();
		}
	}, [results])

	const compareIngredients = (firstIngredient, secondIngredient) => {
			let comparison = 0;
			if (firstIngredient.count < secondIngredient.count) {
			  comparison = 1;
			} else if (firstIngredient.count > secondIngredient.count) {
			  comparison = -1;
			}
			return comparison;
	}

	return (
		<div>
			{results?.map((result, index) => 
				renderItem(result, index)
			)}
			{topIngredients?.length ?
			<div>TOP 5 :

			{topIngredients.map((result, index) => 
					index < 5 ?
					<div key={index}>
						{result.name}
					</div>
					: null
				)}
			</div> : null}
		</div>
	);
};

export default ResultsList;